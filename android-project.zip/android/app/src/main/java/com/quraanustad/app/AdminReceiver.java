package com.quraanustad.app;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;

/** Sirf "screen lock" ki ijazat ke liye (force-lock). Koi data nahi padhta/mitata. */
public class AdminReceiver extends DeviceAdminReceiver {

    static ComponentName comp(Context c) {
        return new ComponentName(c, AdminReceiver.class);
    }

    static boolean isActive(Context c) {
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isAdminActive(comp(c));
    }
}
