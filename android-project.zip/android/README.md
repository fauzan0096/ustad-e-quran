# 📱 Quraan Ustad — Android App (azan app band ho tab bhi + asli phone lock)

Ye app aapki website ko hi kholta hai (WebView), aur Android ke alarm/service se:
- 🕌 **Paanchon azan apne waqt par bajti hai — app band ho, screen off ho, tab bhi**
- 🔒 **Phone ki screen 20 minute lock** (Device Admin ki "force-lock" ijazat se; unlock karte hi dobara lock, call ke dauran nahi)
- 🔁 Phone restart ke baad alarm khud dobara lag jaate hain, kal ka waqt khud internet se aa jaata hai
- Sirf **Android 10+**. iPhone par aisa kuch mumkin nahi.

## APK kaise banayein (GitHub par, koi software install nahi)
1. Repo ke root mein ye daalein: **`android/`** folder aur **`.github/workflows/android.yml`**
   (repo ke root mein `icon-192.png` aur teeno `azan-*.mp3` pehle se hon — woh khud use ho jayengi).
2. `android/app/build.gradle` mein `APP_URL` apni website ke link par check karein (abhi `https://quraan-ustad.github.io/`).
3. GitHub → **Actions** tab → **"Android APK banao"** → **Run workflow**. 3-5 minute mein khatam.
4. Run kholein → neeche **Artifacts → QuraanUstad-APK** download karein → zip se `app-debug.apk` nikalein.
5. Phone mein APK kholein → "Unknown sources" ki ijazat dein → Install.

## Phone mein pehli baar setup
1. App kholein → login karein.
2. **Dropdown → 🕌 Namaz ka Hisaab** → **📍 Location se azan ke waqt lein**.
3. **🔓 Phone lock ki ijazat dein** dabayein → Android ki screen par **Activate** dabayein.
4. **🧪 Azan + phone lock ka test (15 sec)** se check karein.
5. Notification ki ijazat "Allow" dein.
6. Xiaomi / Oppo / Vivo / Realme / Samsung: Settings → Battery → Quraan Ustad → **Unrestricted** (aur Autostart ON), warna company ka battery-saver alarm rok sakta hai.

## Lock band karna ho
- Namaz panel mein **"🔒 Azan par 20 min lock lagana hai?"** ka tick hata dein (azan phir bhi bajegi).
- Ya Android Settings → Security → **Device admin apps** → Quraan Ustad → band.
- Awaaz band: panel mein "Azan ki awaaz" → "Awaaz band".

## Dhyan
- Lock ke dauran emergency call / incoming call kaam karti hai. Lock sirf 20 minute (test mein 15 sec) ke liye hai.
- Ye "debug" APK hai (sideload ke liye). Play Store ke liye alag signing + Google ki policy chahiye (Device Admin wali apps ko wahan sakht review hota hai).
- Android ka version/company badal sakti hai ke alarm kaise bajta hai — pehle apne phone par test zaroor karein.
